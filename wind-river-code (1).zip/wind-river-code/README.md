#### prerequisites:
    
    * docker
    * kubectl

## **Build the docker image**
sudo docker build --tag wind-river-code .

## Start the docker container to run the app in local
sudo docker run --name wind-river-code -p 9090:9090 wind-river-code

## publishing the container image to cloud repo
sudo docker tag wind-river-code:latest wind-river-code:0.1

## Push the container image to repo
sudo docker push wind-river-code

## deploying app to kubernetes
kubectl apply -f deployment.yaml

##API Endpoints
* localhost:6000/api/health - health checking API

`Sample response:
{
    "server health": "GREEN"
}`

* localhost:6000/api/encrypt - encryption API

`Sample response:
{
    "Input": "plain text",
    "Message": "encryption successful",
    "Output": "Encrypted_plain text_String",
    "Status": "success"
}`
* localhost:6000/api/decrypt - decryption API

`Sample response:
{
    "Input": "Encrypted_plain text_String",
    "Message": "decryption successful",
    "Output": "plain text",
    "Status": "success"
}`